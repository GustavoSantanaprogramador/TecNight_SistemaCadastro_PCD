/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_tecnightsenai;

/**
 *
 * @author gsantana
 */
public class Projeto_TecNightSenai {

    public static void main(String[] args) {
        System.out.println("bom dia!");
        System.out.println("Bom tarde");
                System.out.println("Lahra passou por aqui");
                   System.out.println("huahauahuauh");

        
        
    }
}
